package com.choucair.newExperience.stepdefinitions;

import com.choucair.newExperience.questions.ValidateSectionWomen;
import com.choucair.newExperience.tasks.SelectWomenSection;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;
import net.thucydides.core.annotations.ClearCookiesPolicy;
import net.thucydides.core.annotations.Managed;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebDriver;

public class ProductSectionsStepDefinitions {

    @Managed(clearCookies = ClearCookiesPolicy.BeforeEachTest)
    public WebDriver hisBrowser;

    @Before
    public void setUp(){
        OnStage.setTheStage(Cast.whereEveryoneCan(BrowseTheWeb.with(hisBrowser)));
        OnStage.theActorCalled("Linda");
    }


    @Given("^The user is on home page$")
    public void theUserIsOnHomePage() {
        OnStage.theActorInTheSpotlight().wasAbleTo(Open.url("http://automationpractice.com/index.php"));

    }

    @When("^The user click on the Women section$")
    public void theUserClickOnTheWomenSection() {
        OnStage.theActorInTheSpotlight().attemptsTo(SelectWomenSection.selectWomenSection());
    }

    @Then("^The user should only see the products related to \"([^\"]*)\" section$")
    public void theUserShouldOnlySeeTheProductsRelatedToSection(String arg1) {
        OnStage.theActorInTheSpotlight().should(GivenWhenThen.seeThat(ValidateSectionWomen.sectionWomen(), Matchers.equalTo(arg1)));

    }

    @When("^The user click on the Dresses section$")
    public void theUserClickOnTheDressesSection() {
    }

    @Then("^The user should only see the products related to Dresses section$")
    public void theUserShouldOnlySeeTheProductsRelatedToDressesSection() {

    }

    @When("^The user click on the T-shirts section$")
    public void theUserClickOnTheTShirtsSection() {
    }

    @Then("^The user should only see the products related to T-shirts section$")
    public void theUserShouldOnlySeeTheProductsRelatedToTShirtsSection() {
    }

}
