package com.choucair.newExperience.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

// runner interconecta los feature y los step definitions

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src\\test\\resources\\product_sections.feature",
        glue = "com.choucair.newExperience.stepdefinitions",
        snippets = SnippetType.CAMELCASE,
        tags = "@Women")

public class ProductSections {


}
