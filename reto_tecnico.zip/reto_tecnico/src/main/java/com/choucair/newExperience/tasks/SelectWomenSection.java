package com.choucair.newExperience.tasks;

import com.choucair.newExperience.userInterfaces.MainPage;
import gherkin.cli.Main;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.actions.ScrollTo;

public class SelectWomenSection implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(MainPage.BUTTON_WOMEN));
        actor.attemptsTo(Scroll.to(MainPage.IMG_WOMEN));
        actor.attemptsTo(MoveMouse.to(MainPage.IMG_WOMEN));
        actor.attemptsTo(Click.on(MainPage.BUTTON_MORE));
    }


    public static SelectWomenSection selectWomenSection(){
        return Tasks.instrumented(SelectWomenSection.class);
    }


}
