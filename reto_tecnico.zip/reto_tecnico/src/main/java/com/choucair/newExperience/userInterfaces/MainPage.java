package com.choucair.newExperience.userInterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class MainPage {

    public static final Target BUTTON_WOMEN = Target.the("button section Women").
            located(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/a"));

    public static final Target BUTTON_DRESSES = Target.the("button section Dresses").
            located(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a"));

    public static final Target BUTTON_TSHIRTS = Target.the("button section T-shirts").
            located(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a"));

    public static final Target IMG_WOMEN = Target.the("image women").
            located(By.xpath("//*[@id=\"center_column\"]/ul/li[5]/div/div[1]/div/a[1]/img"));

    public static final Target BUTTON_MORE = Target.the("button more").
            located(By.xpath("//*[@id=\"center_column\"]/ul/li[5]/div/div[2]/div[2]/a[2]"));

    public static final Target TXT_WOMEN = Target.the("text women").
            located(By.xpath("//*[@id=\"columns\"]/div[1]/a[2]"));



}
