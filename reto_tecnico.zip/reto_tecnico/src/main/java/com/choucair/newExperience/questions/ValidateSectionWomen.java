package com.choucair.newExperience.questions;

import com.choucair.newExperience.userInterfaces.MainPage;
import cucumber.api.java.es.E;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;


public class ValidateSectionWomen implements Question {

    @Override
    public Object answeredBy(Actor actor) {
        String textSection = MainPage.TXT_WOMEN.resolveFor(actor).getText();
        return textSection;
    }

    public static ValidateSectionWomen sectionWomen(){
        return new ValidateSectionWomen();
    }
}
